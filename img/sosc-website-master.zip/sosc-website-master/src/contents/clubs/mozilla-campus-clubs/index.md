---
slug: /clubs/mozillacampusclubs
name: Mozilla Campus Clubs
logo: './club-logo.jpg'
contact_phone: '9876543210'
contact_email: 'example@mail.com'
members: 
    - githubUserName
---