---
slug: /clubs/djangogirlsmangaluru
name: DjangoGirls Mangaluru
logo: './dg-logo.png'
contact_phone: '9876543210'
contact_email: 'example@mail.com'
members: 
    - githubUserName
---