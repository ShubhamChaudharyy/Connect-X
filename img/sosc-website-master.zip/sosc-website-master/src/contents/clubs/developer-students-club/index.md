---
slug: /clubs/dsc
name: Developer Students Club
logo: './dsc-logo.png'
contact_phone: '8762317931'
contact_email: 'akshay.bhat981222@gmail.com'
members: 
    - akshayrb22
---
