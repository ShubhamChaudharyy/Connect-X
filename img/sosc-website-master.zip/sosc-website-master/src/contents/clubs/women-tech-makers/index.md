---
slug: /clubs/wtm
name: Women Tech Makers
logo: './wtm-logo.png'
contact_phone: '9876543210'
contact_email: 'example@mail.com'
members: 
    - githubUserName
---