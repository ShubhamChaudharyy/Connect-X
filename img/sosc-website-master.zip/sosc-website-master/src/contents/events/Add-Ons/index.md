---
slug: /events/Add-Ons-Workshop
name: Mozilla Add-Ons
date: 2019-04-27
location: Ground Floor Seminar Hall
cover: './Add-Ons-Cover.png'
link: https://forms.gle/z7Z7RaCz8d91B5DY8
feedback_link: https://docs.google.com/forms/d/e/1FAIpQLSdBb5V61Ap3G9ShxGIkKG0QFYPYis4hazNfmDvM-QfVag8e1Q/viewform?usp=sf_link
---

## Mozilla Add-Ons Workshop
An introduction to the world of Browser Add-Ons, in collaboration with ACM Mozilla Interest Group for Open Source, where participants from different colleges will learn to use, and develop their own Browser Add-ons

## Time
11:00 AM to 6:00 PM

## Prerequisites
* Laptop

## Speakers
- Adithya Karia
- Bharath

## Topics covered:
* Introduction to Add-On Development
* Demo and overview of APIs
* Hands on Session
* Review & publishing them to AMO

