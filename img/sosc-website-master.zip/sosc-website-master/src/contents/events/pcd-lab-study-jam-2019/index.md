---
slug: /events/pcd-lab-study-jam-2019
name: PCD Lab Study Jam
date: 2019-01-19
location: Intel Lab
cover: './cover.png'
link: https://goo.gl/forms/X2iv4VagqaUPNT3U2
feedback_link: https://goo.gl/forms/sg2UOmQAJLahbpWe2
---

## PCD Lab programs Study Jam
This Study Jam is concentrated on clearing all the doubts and questions in your PCD Lab programs. We'll be going through all the lab programs with hands on training and possible viva questions to break the ice. If you face any difficulty in learning or executing C programs, understanding the algorithms and concepts, this study jam is for you. This is a free and community driven event, open for all.

### Time: Saturday, 1:30 PM

## Topics Covered
- All the PCD Lab Programs with Practical
- VIVA questions related to each program

## Trainers and Mentors
- [Abhishek P](https://github.com/AbhiiGatty), Community Lead - SOSC
- [Musthaq Ahamad](https://github.com/haxzie), GitHub Campus Expert | Community Lead - SOSC
