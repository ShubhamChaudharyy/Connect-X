---
slug: /events/ABC-in-python
name: ABC in Python
date: 2019-02-16
location: iwave Lab (tentaive)
cover: './cover.png'
link: https://goo.gl/forms/4QAuyyW1AuBWIgrg2
feedback_link: https://goo.gl/forms/Ro6J3CI8oX1zbqZo2
---
## ABC in Python
ABC in Python (Anybody can Code in Python) is an introductory python workshop conducted in collaboration with Mozilla campus club and SOSWC.This workshop will help you in getting started with python programming. This workshop is for the beginners hence you do not need to have any prior programming knowledge. 
To register [click here](https://goo.gl/forms/4QAuyyW1AuBWIgrg2).

##Prerequistie
- Laptop
- Python 3 installed
Follow [this link](https://realpython.com/installing-python/
) to guide you through the installation.

## Venue
Saturday, 16-Feb-19 - 1:30PM  


