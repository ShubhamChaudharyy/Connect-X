---
username: Breathedude
name:  B Rachitha
designation: Co-Management and Sponsorship Head
email: rachithabayar@gmail.com
linkedin: https://www.linkedin.com/in/rachitha-bayar-2746ab13a/
skills: C, Java, Python, Content Writing, Public Speaking. 
---
