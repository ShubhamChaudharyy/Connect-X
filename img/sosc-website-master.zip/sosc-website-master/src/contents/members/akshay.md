---
username: akshayrb22
name: Akshay Ram Bhat
designation: Technical Lead
email: akshay.bhat981222@gmail.com
linkedin: www.linkedin.com/in/akshayrb22
skills: Python, Machine Learning, Data Science
---
