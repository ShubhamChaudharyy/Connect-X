--- 
username: ShreyasBaliga
name: Shreyas Baliga
designation: Co-Project Coordinator 
emai: bshreyasbaliga@gmail.com 
linkedin: https://www.linkedin.co/in/shreyas-baliga 
skills: Android, Computer Vision
---
