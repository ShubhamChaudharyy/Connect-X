---
username: AbhiiGatty
name: Abhishek P
designation: Community Lead
email: abhiigatty@gmail.com
linkedin: www.linkedin.com/in/abhiigatty
skills: Net Sec, System Architecture design, Python, Ruby
---
