---
username: monisha16
name: Monisha Tarkar
designation: Head of sponsorship and marketing
email: monishatarkar1625@gmail.com
linkedin: https://www.linkedin.com/in/monisha-tarkar/
skills: C,C++,Java,Blockchain,Adobe Photoshop
---
