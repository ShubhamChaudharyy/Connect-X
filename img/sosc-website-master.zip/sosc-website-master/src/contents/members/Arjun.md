---
username: arjunsuvarna1
name: Arjun Suvarna
designation: Chairperson | DSC Lead
email: arjunsuvarna.s@gmail.com
linkedin: https://www.linkedin.com/in/arjun-suvarana-094299121
skills: Devops, Automation, Data Science, Public Speaking
---
