---
username: jehadmohamedz
name: Jehad Mohamed
designation: Vice Chairperson | Mozilla club captain
email: jehadmohamedz@gmail.com
linkedin: https://www.linkedin.com/in/jehad-ddx/
skills: Computer vision,Design Thinking,AR/VR
---
