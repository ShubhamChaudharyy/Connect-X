---
username: melwinlobo18
name: Melwin Lobo
designation: Project Head
email: melwinlobo18@gmail.com
linkedin: www.linkedin.com/in/melwin-l-6356a413a
skills: Deep Learning, Python
---
