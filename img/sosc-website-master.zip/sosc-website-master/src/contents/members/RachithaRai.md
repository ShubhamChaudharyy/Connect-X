---
username: RachithaRai
name: Rachitha Rai
designation: Member
email: rachitharai3016@gmail.com
linkedin: https://linkedin.com/
skills: C,Public speaking,Content writing
---
