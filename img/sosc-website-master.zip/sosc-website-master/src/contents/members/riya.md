---
username: riiyabatra
name: Riya Batra
designation: Finance Head
email: riiyabatra@gmail.com
linkedin: https://linkedin.com/in/riya-batra/
skills: c, c++, java, machine learning
---
