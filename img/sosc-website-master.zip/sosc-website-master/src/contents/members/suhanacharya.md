---
username: suhanacharya
name: Suhan Acharya
designation: Member
email: suhan.acharya1@gmail.com
linkedin: https://www.linkedin.com/in/suhan-acharya-64a09a170/
skills: Machine Learning, Python, GNU Octave
---
