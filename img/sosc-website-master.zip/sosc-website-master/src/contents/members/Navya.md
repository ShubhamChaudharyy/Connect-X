---
username: navyabhat98
name: Navya Bhat
designation: Chairperson
email: blnavya@gmail.com
linkedin: www.linkedin.com/in/navya-bhat-14b1a4160
skills: Content Writing, Blogging, Planning, Marketing, C,C++,java,python.
---
