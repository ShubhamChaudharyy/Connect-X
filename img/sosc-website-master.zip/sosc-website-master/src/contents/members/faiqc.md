---
username: faiqc
name: Faiq Chilmi
designation: Co-Technical Head
email: faiqc7@gmail.com.
linkedin: https://www.linkedin.com/in/faiqchilmi
skills: Video Editing, Pytyhon
---
