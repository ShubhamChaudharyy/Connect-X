---
username: ambx
name: Hiba Fathima
email: hiba.hf123@gmail.com
linkedin: https://linkedin.com/in/ambx
skills: Public Speaking, Technical Writing, Java
designation: Member
---
