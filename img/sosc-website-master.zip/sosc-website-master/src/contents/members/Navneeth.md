---
username: mnavneethkrishna
name: Navneeth Krishna
designation: Head HR
email: mnkb20@gmail.com
linkedin: https://www.linkedin.com/in/navneeth-krishna-b3874412a/
skills: Deep Learning, Machine Learning, Data Science, Presentation and Strategy
---
