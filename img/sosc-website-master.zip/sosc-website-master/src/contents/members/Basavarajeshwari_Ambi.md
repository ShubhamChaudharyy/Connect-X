---
username: Basavarajeshwari-Ambi
name: Basavarajeshwari Ambi
designation: Mozilla Club Captain | Co Sponsorship Head
email: breshwari99@gmail.com
linkedin: https://www.linkedin.com/in/basavarajeshwari-ambi-1b223016a
skills: AR/VR,Product Development,Marketing,C,C++,Html
---
