---
username: ekokratos
name: Adithya M Suvarna
designation: Community Lead
email: adithyams.adi@gmail.com
linkedin: https:www.linkedin.com/in/adithya-suvarna
skills: Python, Game development, Arduino
---
