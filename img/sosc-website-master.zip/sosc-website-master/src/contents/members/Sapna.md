---
username: sapnakg
name: Sapna Kumari Goad
designation: Event Coordinator
email: sapnamgoad1998@gmail.com
linkedin: YOUR_LINKEDIN_PROFILE_URL (optional)
skills: c,c++,java,marketting
---
