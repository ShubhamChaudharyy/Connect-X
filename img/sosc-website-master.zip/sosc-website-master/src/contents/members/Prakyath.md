---
username: Prakyath98
name: Prakyath
designation: Event coordinator
email: prakyath98@gmail.com
skills: c,c++,java, marketing
---
