---
username: FernandisNewton
name: Newton Fernandis
designation: Member
email: newton.fernandis@gmail.com
linkedin: https://www.linkedin.com/in/newton-fernandis/
skills: Game Development,programming, web
---
