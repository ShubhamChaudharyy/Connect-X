---
username: akashdeepb
name: Akashdeep Bhagat
designation: Community Lead | GitHub Campus Expert
email: akashdeepb.cs17@sahyadri.edu.in
linkedin: https://www.linkedin.com/in/akashdeep-bhagat-689b0b159/
skills: Android, Web, Public Speaking
---
