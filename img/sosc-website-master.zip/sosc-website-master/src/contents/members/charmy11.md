---
username: charmy11
name: Charmi Sanjay Meswani
designation: Community lead
email: cmeswani.meswani56@gmail.com
linkedin: https://www.linkedin.com/in/charmi-meswani-a91395158/
skills: YOUR_SKILLS c,c++,c#,java,public speaking
---
