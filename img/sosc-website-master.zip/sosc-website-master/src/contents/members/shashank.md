---
username: Shanky1199
name: Shashank S
designation: HR
email: shashanks939@gmail.com
linkedin: YOUR_LINKEDIN_PROFILE_URL (optional)
skills: Leadership,Public speaking,OpenSource contributor.
---
