---
username: ruthud
name: Ruthu
designation: Member
email: ruthu.is18@sahyadri.edu.in
linkedin: https://linkedin.com/
skills: C,Design,Public Speaking
---
