---
username: swaaz
name: Swasthik Shetty
designation: Co-Event Management Head
email: swaasthik.shetty07@gmail.com
linkedin: https://www.linkedin.com/in/swasthik-shetty-b50928174/
skills: photography, design,editing,programming  
---
