---
username: jhonnyjester
name: Jonathan Adriel Rodrigues
designation: Member
email: rodriguesjnyadr@gmail.com
linkedin: https://www.linkedin.com/in/jonathan-adriel-rodrigues-0a822b154
skills: Front-End Android App Dev
---
