---
username: rumaan
name: Rumaan Khalander
designation: Technical Lead
email: rumaankalander@gmail.com
linkedin: https://www.linkedin.com/in/rumaan/
skills: Android, Web, Python, Public speaking
---