module.exports = {
  feedback_days: 7,
}
